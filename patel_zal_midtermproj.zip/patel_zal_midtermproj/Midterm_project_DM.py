import sys

Database_File = input('INPUT FILE NAME WITH PATH OF THE FILE:')
Min_supp = float(input('INPUT SUPPORT (MINIMUM):'))
Min_Confi = float(input('INPUT CONFIDENCE(MINIMUM):'))

with open(Database_File) as fl:
    Database_Transactions = []
    for ln in fl:
        data_b = ln.replace('\n', '').split(",")
        Database_Transactions.append(data_b)
    for trs in Database_Transactions:
        print(trs)


class Rule:

    def __init__(self, left_, right_, all_):
        self.left_ = list(left_)
        self.left_.sort()
        self.right_ = list(right_)
        self.right_.sort()
        self.all_ = all_

    def __str__(self):
        return ",".join(self.left_)+" --> "+",".join(self.right_) + " ---- "

    def __hash__(self):
        """
        Store support value to dict
        :return: hash value in the object
        """
        return hash(str(self))

def genC_(key):
    gen_res = []
    len_key = len(key)
    for x in range(len_key):
        for y in range(x+1, len(key)):
            no_ = key[x]
            no1_ = key[y]
            x1 = list(no_)
            x2 = list(no1_)
            x1.sort()
            x2.sort()
            if x1[:len(no_)-1] == x2[:len(no_)-1]: gen_res.append(no_ | no1_)
    return gen_res


def searchAndchk_(Database_Transactions, c_hk):
    cnt_ = {}
    for num_b in c_hk: cnt_[num_b]=0
    for trx in Database_Transactions:
        for fSet_ in c_hk:
            if fSet_.issubset(trx): cnt_[fSet_] += 1
    n = len(Database_Transactions)
    return {fSet_: support/n for fSet_, support in cnt_.items() if support/n >= Min_supp}

def Freq_and_Sup():
    supp = {}
    c = [[]]
    key = [[]]
    z = set()
    for trx in Database_Transactions:
        for item in trx: z.add(frozenset([item]))

    c.append(z)
    cnt_ = searchAndchk_(Database_Transactions, z)
    key.append(list(cnt_.keys()))
    supp.update(cnt_)

    i = 1
    while len(key[i]) > 0:
        c.append(genC_(key[i]))
        cnt_ = searchAndchk_(Database_Transactions, c[i+1])
        supp.update(cnt_)
        key.append(list(cnt_.keys()))
        i = i + 1
    return key, supp


def Ass_subrule(freqs_, rightset_, res, supp):
    s_right = len(rightset_[0])
    s_total = len(freqs_)
    if s_total-s_right > 0:
        rightset_ = genC_(rightset_)
        addright_ = []
        for right_ in rightset_:
            left_ = freqs_ - right_
            if len(left_) == 0:
                continue
            confidence = supp[freqs_] / supp[left_]
            if confidence >= Min_Confi:
                res.append([Rule(left_, right_, freqs_), supp[freqs_],  confidence])
                addright_.append(right_)

        if len(addright_) > 1: Ass_subrule(freqs_, addright_, res, supp)


def Ass_rule_(fq, sup):
    all_res = []
    for x in range(2, len(fq)):
        if len(fq[x]) == 0:
            break
        freq_sets = fq[x]

        for freqs_ in freq_sets:
            for right_ in [frozenset([val]) for val in freqs_]:
                left_ = freqs_-right_
                confidence = sup[freqs_] / sup[left_]
                if confidence >= Min_Confi:
                    all_res.append([Rule(left_, right_, freqs_), sup[freqs_], confidence])

        if len(freq_sets[0]) != 2:

            for freqs_ in freq_sets:
                right_ = [frozenset([val]) for val in freqs_]
                Ass_subrule(freqs_, right_, all_res, sup)

    all_res.sort(key=lambda val: str(val[0]))
    return all_res


if __name__ == '__main__':
    freq, s = Freq_and_Sup()
    val = Ass_rule_(freq, s)
    print("\n-----Rules-----Support-----Confidence-----")
    for a in val:
        b = str(a[0])
        b1 = str(a[1])
        b2 = str(a[2])
        print(b, 'Support is: '+b1, "Confidence is: "+b2)
